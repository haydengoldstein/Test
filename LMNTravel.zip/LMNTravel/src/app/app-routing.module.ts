import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsersComponent } from './users/users.component';
import {DestinationComponent} from './destination/destination.component'
import { UsernumbersComponent } from './usernumbers/usernumbers.component';
import {User} from '../app/User';
const routes: Routes = [ 
{ path: 'Users', component: UsersComponent,data:{}},
{ path: 'Destination', component: DestinationComponent,data:{} },
{ path: 'Usernumbers', component: UsernumbersComponent,data:{} },
{path: '', redirectTo: '/Users', pathMatch: 'full'}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
