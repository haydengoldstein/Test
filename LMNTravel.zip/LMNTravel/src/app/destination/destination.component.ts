import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersService } from '../users.service';
import {User} from '../User'
@Component({
  selector: 'app-destination',
  templateUrl: './destination.component.html',
  styleUrls: ['./destination.component.css']
})
export class DestinationComponent implements OnInit {
  dateTo:any;
  dateFrom:any;
  selectedCity:any;
  uniqueCity:any;
  numberofDays:any;
  UserDestination:any;
  cityError =true;
  user:User ={name:"",age:0,city:""};
  @Input() selectedUsertxt:any;
    constructor(private usersService:UsersService,private fb: FormBuilder,private router:Router,private activatedroute:ActivatedRoute) 
    { 
      //this.usersService.getUsers().subscirbe
      var users:any =  this.usersService.getUsers()
      .subscribe(users => this.uniqueCity = [...new Set(users.map(item =>item.city))]);
console.log(this.router.getCurrentNavigation()?.extras?.state);
      this.selectedUsertxt = this.router.getCurrentNavigation()?.extras?.state?.['example'];
      
    //  this.router.getCurrentNavigation().extras.state;
     
    }
  
    ngOnInit(): void {
      this.createGroup();
      this.activatedroute.data.subscribe(data => {
        var product=data;
        console.log(product);
    });
    }
  
  public cityChange():void
  {
   // this.caclNumdays();
   //this.isSameCity();
   if(!this.isSameCity())
   {
    this.userNumbersPage();
   }
    //this.cityChange();
    
  }
  
  public caclNumdays(): void {
    //  this.numberofDays = this.dateFrom - this.dateTo;
    console.log(this.selectedUsertxt);
      var a = Date.parse(this.dateFrom);
      var b = Date.parse(this.dateTo);
      var Time = b - a; 
      var Days = Time / (1000 * 3600 * 24);
      this.numberofDays = -1*Days;
      console.log(this.dateFrom);
      console.log(this.dateTo);
      console.log(Time);
      console.log(Days)
     // return this;
  }
  
  
  
  createGroup()
  {
    this.UserDestination = new FormGroup(
      {DateFrom: new FormControl(),
      DateTo: new FormControl(),
      numberOfDays:new FormControl(),
      selectedCity:new FormControl()});
    }

    getCurrentUser(user:User)
    {
      console.log("Current "+user.name)
      this.user =user;
      
    }
    public isSameCity():boolean
    {
       var result = false;
    
      this.usersService.getUsers()
      .subscribe((users: any[])=>{
       var res = users.find((obj:any)=>{
         console.log(this.selectedUsertxt);
         console.log('selected'+this.UserDestination.controls['selectedCity'].value);
         return obj.name === this.selectedUsertxt;
       
        });
        this.getCurrentUser(res);
        console.log(res?.city);
        if(res?.city === this.UserDestination.controls['selectedCity'].value)
        {
         
          result = true;
          this.cityError = false;
        }
        else
        {
          this.cityError = true;
          console.log("City not valid");
        }
        
      });
      return result;
    }

public userNumbersPage():void
{
  this.router.navigate(['/Usernumbers'],{state:{example:{"name":this.user.name,"age":this.user.age,
   "datefrom":this.UserDestination.controls['DateFrom'].value, "dateto":this.UserDestination.controls['DateTo'].value
   , "selectedCity":this.UserDestination.controls['selectedCity'].value, "numberofdays":this.UserDestination.controls['numberOfDays'].value}}} ); 
}
  
  }
 