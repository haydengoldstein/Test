import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../User';

@Component({
  selector: 'app-usernumbers',
  templateUrl: './usernumbers.component.html',
  styleUrls: ['./usernumbers.component.css']
})
export class UsernumbersComponent implements OnInit {
  UserNumbers: any;
  IdNum: any;
  PhoneNum: any;
  phoneErr = false;
  IdNumErr = false;
  user: any = { name: "", age: 0, city: "", datefrom: new Date(), dateto: new Date(), selectedCity: "", numberofdays: 0 };
  validAge = true;
  constructor(private fb: FormBuilder, private router: Router) {
   
    this.user = this.router.getCurrentNavigation()?.extras?.state?.['example'];

  }

  ngOnInit(): void {

    this.createGroup();
  }

  createGroup() {
    this.UserNumbers = new FormGroup({

      IdNum: new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.minLength(13), Validators.maxLength(13)]),
      PhoneNum: new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)])
    })


  }

 

  keyPress(event: any, caller: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    console.log(event);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      if (caller = 'id') {
        this.IdNumErr = true;
      }
      if (caller = 'phone') {
        this.phoneErr = true;
      }
      event.preventDefault();
    }
    else {
      if (caller = 'id') {
        this.IdNumErr = false;
      }
      if (caller = 'phone') {
        this.phoneErr = false;
      }
    }
  }

  calculateUser(): boolean {
    var userYear = new Date(Date.parse(this.UserNumbers.controls['IdNum'].value.slice(0, 2) + "," + this.UserNumbers.controls['IdNum'].value.slice(3, 4) + "," + this.UserNumbers.controls['IdNum'].value.slice(5, 6)));
    //date =this.UserNumbers.controls['IdNum'].value.slice(0, 2),
    //var dob = Date()

    var calcAge = new Date().getFullYear() - userYear.getFullYear();
 
    if (this.user.age != calcAge) {
      this.validAge = true;
    } else {
      this.validAge = false;
    }
    return this.validAge;
  }
}
