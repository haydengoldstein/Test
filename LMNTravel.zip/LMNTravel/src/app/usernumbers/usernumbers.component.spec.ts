import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsernumbersComponent } from './usernumbers.component';

describe('UsernumbersComponent', () => {
  let component: UsernumbersComponent;
  let fixture: ComponentFixture<UsernumbersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsernumbersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UsernumbersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
