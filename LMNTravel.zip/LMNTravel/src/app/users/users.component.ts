import { Component, Input, OnInit } from '@angular/core';

import { FormBuilder, FormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UsersService } from '../users.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  userGroup: any;

  users: any[] = [];
  selectedUser: any;
  selectedUsertxt: any;
  constructor(private fb: FormBuilder, private userService: UsersService, private router: Router) {
    this.getUsers();
  }

  ngOnInit(): void {
    this.createGroup();
  }

  createGroup() {
    this.userGroup = new FormGroup({
      selectedUser: new FormControl(null, [Validators.required]),
     /* DateFrom: new FormControl(),
      DateTo: new FormControl(),
      //:new FormControl(),
      IdNumber: new FormControl(),
      numberOfDays: new FormControl(),
      selectedCity: new FormControl(),
      cellNumber: new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)])*/
    })
  }
  public onSubmit(): void {
    console.log(this.userGroup.controls);
  }
  public getUsers() {
    
    this.userService.getUsers()
      .subscribe((users: any[]) => this.users = users);
    
  }

  public destinationPage(): void {
   
    this.router.navigate(['/Destination'], { state: { example: this.userGroup.controls['selectedUser'].value } });
  }
}
