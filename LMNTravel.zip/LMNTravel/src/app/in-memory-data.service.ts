import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService {
  createDb() {
    const musers =[
      {"name": "Vusi",
      "age" :21,
      "city" :"JHB"
      
      }, {
      
      "name": "Thando",
      "age" :28,
      "city" :"CPT"
      
      }, {
      
      "name": "Anele",
      "age" :30,
      "city" :"PE"
      
      }, {
      
      "name": "Lisa",
      "age" :26,
      "city" :"DUR"
      
      }, {
      
      "name": "Linda",
      "age" :19,
      "city" :"JHB"
      
      }
      , {
      
          "name": "Keleabetswe1",
          "age" :29,
          "city" :"PTA"
          
          }
    ];
    return {musers}
  }
}
