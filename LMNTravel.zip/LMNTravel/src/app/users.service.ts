import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { USERS } from './sampleUsers';
import {User} from './User'
@Injectable({
  providedIn: 'root'
})

export class UsersService {
  private usersUrl = 'api/musers'; 

  getUsers() {

   //return this.http.get<User[]>(this.usersUrl)
    const users = of(USERS);
     return users;
    //throw new Error('Method not implemented.');
  }

  constructor(  private http: HttpClient) { }
}
